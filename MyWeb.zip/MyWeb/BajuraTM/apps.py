from django.apps import AppConfig


class BajuratmConfig(AppConfig):
    name = 'BajuraTM'
