from django.http import HttpResponse
from django.shortcuts import render
from .MyDataTM import contact


def home(req):
	content = [ 'Contact' , 'Dawnload', 'Login', 'Settings']
	return render(req, 'home_page.html', {'data': content, 'Devloper': contact.contact})
