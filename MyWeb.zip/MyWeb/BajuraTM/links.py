from django.urls import path
from . import setup

urlpatterns = [
	path('', setup.home, name='home'),
]