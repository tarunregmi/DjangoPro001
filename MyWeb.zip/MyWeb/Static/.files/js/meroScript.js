/******* Decleration of globel Veriable *******/
	var tab, suchiLooka, bhado, suchiChild;
		tab = document.querySelector('.tab');
		suchiLooka = document.querySelector('.suchiLooka');
		suchiChild = suchiLooka.childElementCount;
		bhado = document.querySelector('.bhado');
		tab.addEventListener('click', tabClick)
	var rekha = [];
		for(var i=0; i<3; i++){
			rekha[i] = document.querySelector('.rekha' + i);
		}
	function tabClick(){
		for(var j=0; j<rekha.length; j++){
			rekha[j].classList.toggle('rekhaClick');
			rekha[j].classList.toggle('rekha' +j+ 'Click');
		}
		suchiLooka.classList.toggle('suchiDekha');
		bhado.addEventListener('click', bhadoKhali);
		bhado.addEventListener('touchmove', bhadoKhali);
/******* Content List *******/
		for(var i=0; i<suchiChild; i++){
			suchiLooka.children[i].addEventListener('click', bhadoKhali);
			suchiLooka.children[i].addEventListener('click', innert);
		}
		var debug = document.querySelector('.debug')
		function innert(ev){
			debug.innerHTML = ev.target.innerHTML;
			
		}
		function bhadoKhali(){
			for(var j=0; j<rekha.length; j++){
				rekha[j].classList.remove('rekhaClick');
				rekha[j].classList.remove('rekha' +j+ 'Click');
			}
			suchiLooka.classList.remove('suchiDekha');
			bhado.removeEventListener('click', bhadoKhali);
			bhado.removeEventListener('touchmove', bhadoKhali);
		}
	}